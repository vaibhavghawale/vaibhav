package com.masai;

public interface Shape {
    public void drawIt();
}
